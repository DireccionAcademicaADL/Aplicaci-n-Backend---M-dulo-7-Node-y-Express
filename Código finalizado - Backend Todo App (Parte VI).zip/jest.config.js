export default {
  testEnvironment: "jest-environment-node",
  transform: {},
};
