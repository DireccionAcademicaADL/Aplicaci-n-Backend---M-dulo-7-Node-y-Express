# Aplicación Backend - Módulo Node y Express
Esta aplicación backend corresponde al ejercicio explicado en las guías complementarias del módulo
